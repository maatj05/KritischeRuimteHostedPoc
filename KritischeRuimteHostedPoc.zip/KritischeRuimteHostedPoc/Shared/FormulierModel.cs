﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KritischeRuimteHostedPoc.Shared
{
    public class FormulierModel
    {
        public string signatureString { get; set; }
        public string Name { get; set; }
        public DateTime DateOfBirth { get; set; }
    }
}
