﻿
namespace KritischeRuimteHostedPoc.Server.Services
{
    public interface IRenderHtml
    {
        Task<string> Generate(KritischeRuimteHostedPoc.Shared.CreatePdfRequest model);
    }
}