﻿using KritischeRuimteHostedPoc.Shared;
using PdfSharp;
using PdfSharp.Pdf;
using PuppeteerSharp;
using PuppeteerSharp.Media;

 
namespace KritischeRuimteHostedPoc.Server.Services
{
    public class PuppeteerImpl :IPdfFormCreator 
    {


        public PuppeteerImpl(
            IWebHostEnvironment hostEnvironment, 
            IRenderHtml renderHtml
            )
        {
            this.hostEnvironment = hostEnvironment;
            this.renderHtml = renderHtml;
        }

        private readonly IWebHostEnvironment hostEnvironment;
        private readonly IRenderHtml renderHtml;

        public async Task<string> Create(string html, string relativeFilePath)
        {

            string file = System.IO.Path.Combine("pdf", $"file-{Guid.NewGuid()}.pdf");
            //using var browserFetcher = new BrowserFetcher();
            string filePath = System.IO.Path.Combine(hostEnvironment.WebRootPath, file);
            //await browserFetcher.DownloadAsync();
            await using var browser = await Puppeteer.LaunchAsync(new LaunchOptions { Headless = true });
            await using var page = await browser.NewPageAsync();
            //await page.GoToAsync("http://www.google.com");
            //await page.ScreenshotAsync(filePath);

            await page.SetContentAsync(html);
            var result = await page.GetContentAsync();
            //await page.EvaluateExpressionHandleAsync("document.fonts.ready"); // Wait for fonts to be loaded. Omitting this might result in no text rendered in pdf.
            await page.PdfAsync(filePath);
            //await using var page = await browser.NewPageAsync();
            //pdf.Save(filePth);
            return file;

        }
 
    }
}
