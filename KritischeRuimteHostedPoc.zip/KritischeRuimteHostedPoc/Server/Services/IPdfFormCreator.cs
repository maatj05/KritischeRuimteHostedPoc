﻿using KritischeRuimteHostedPoc.Shared;

namespace KritischeRuimteHostedPoc.Server.Services
{
    public interface IPdfFormCreator
    {
        Task<string> Create(string html, string relativeFilePath);
    }
}