﻿using KritischeRuimteHostedPoc.Server.ViewModels;

namespace KritischeRuimteHostedPoc.Server.Services
{
    public class RenderHtml : IRenderHtml
    {
        private readonly ITemplateService templateService;

        public RenderHtml(Services.ITemplateService templateService)
        {
            this.templateService = templateService;
        }
        public async Task<string> Generate(KritischeRuimteHostedPoc.Shared.CreatePdfRequest model)
        {
           // var model = new InvoiceViewModel
           // {
           //     CreatedAt = DateTime.Now,
           //     Due = DateTime.Now.AddDays(10),
           //     Id = 12533,
           //     AddressLine = "Jumpy St. 99",
           //     City = "Trampoline",
           //     ZipCode = "22-113",
           //     CompanyName = "Jumping Rabbit Co.",
           //     PaymentMethod = "Check",
           //     Items = new List<InvoiceItemViewModel>
           //{
           //    new InvoiceItemViewModel("Website design", 621.99m),
           //    new InvoiceItemViewModel("Website creation", 1231.99m)
           //}
           // };
            var html = await templateService.RenderAsync("Templates/InvoiceTemplate", model);
            return html;
        }
    }


}


